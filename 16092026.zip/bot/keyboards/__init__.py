"""Клавиатуры (inline / reply) бота."""
