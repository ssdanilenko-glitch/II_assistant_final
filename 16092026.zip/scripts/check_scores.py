
import asyncio
from app.core.config import get_settings
from app.services.rag import RAGService


async def main():
    s = get_settings()
    rag = RAGService(s)
    await asyncio.to_thread(rag.build)

    queries = [
        "Как получить доступ к системе 1С:ЕРП?",
        "Как подключить личный кабинет?",
        "Как подать заявку на подключение к ИТ ресурсам?",
        "Как подключить wifi на БМЗ?",
        "Как оформить акт о несоответствии?",
    ]
    for q in queries:
        r = await rag.answer(q)
        score = r.get("top_score")
        conf = r.get("confident")
        ans = (r.get("answer") or "")[:80]
        print(f"Q: {q}")
        print(f"   score={score}  confident={conf}")
        print(f"   answer: {ans!r}")
        print()
    await rag.close()


if __name__ == "__main__":
    asyncio.run(main())
