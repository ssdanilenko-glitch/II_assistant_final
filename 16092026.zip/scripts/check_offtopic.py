
import asyncio
from app.core.config import get_settings
from app.services.rag import RAGService


async def main():
    s = get_settings()
    rag = RAGService(s)
    await asyncio.to_thread(rag.build)

    queries = [
        "Как приготовить плов?",
        "Какая погода в Москве?",
        "Сколько планет в Солнечной системе?",
        "Как настроить личный блог на WordPress?",
        "Расскажи анекдот",
    ]
    for q in queries:
        r = await rag.answer(q)
        print(f"Q: {q}")
        print(f"   score={r.get('top_score')}  confident={r.get('confident')}")
        print()
    await rag.close()


if __name__ == "__main__":
    asyncio.run(main())